package org.wso2.carbon.automation.engine.context;


public enum HostType {
    manager,
    worker
}
